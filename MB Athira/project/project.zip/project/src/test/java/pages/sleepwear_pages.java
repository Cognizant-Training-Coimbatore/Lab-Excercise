package pages;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import baseclass.wrapperclass;
import excelutility.excelReadWrite;


public class sleepwear_pages extends wrapperclass{
	/*WebDriver driver;
	public sleepwear_pages(WebDriver driver) {
		this.driver=driver;
	}*/
	public void women_click() {
		driver.findElement(By.linkText("Women")).click();
	}
	
	public void categorysleepwear_click() {
		driver.findElement(By.xpath("//a[@href=\"/in/en/c/maxwomen-sleepwear\"]")).click();
		
	}
	public boolean filter(int row) throws IOException {
		boolean result=true;
		try {
			String size = null;
			excelReadWrite ex=new excelReadWrite();
			String s=ex.readExcelData(row, 0,"sleepwear.xlsx");
			//driver.findElement(By.linkText(s)).click();
			for(int i=1;i<4;i++)
			{
				
			int y=i+1;
			TimeUnit.SECONDS.sleep(3);
			s=ex.readExcelData(row, i,"sleepwear.xlsx");
			if(i==3)
			{
				size=s;
			}
			driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div/div[2]/div/div/div[1]/div/div["+y+"]/button")).click();
			TimeUnit.SECONDS.sleep(1);
			driver.findElement(By.xpath("//*[@value='"+s+"']")).click();
			TimeUnit.SECONDS.sleep(1);
			}
			s=ex.readExcelData(row, 4,"sleepwear.xlsx");
			driver.findElement(By.linkText(s)).click();
			TimeUnit.SECONDS.sleep(3);
			WebElement li=driver.findElement(By.xpath("//*[@id=\"filter-form-sizes\"]"));
			
			List<WebElement> sizes=(List<WebElement>) li.findElements(By.tagName("li"));
			for(int k=0;k<sizes.size();k++)
			{
				
				if(sizes.get(k).getText().equals(size))
				{
					sizes.get(k).click();
					break;
					
				}
			}
			TimeUnit.SECONDS.sleep(3);
			driver.findElement(By.xpath("/html/body/div[1]/main/div/div[3]/form/div[2]/div/div[1]/fieldset/button[1]")).click();
			ex.writeExcelData("pass", row, "sleepwear.xlsx", 5);
			
		}catch(Exception e) {
			String filename="sleepwear.xlsx";
			String output="fail";
			System.out.println("filter not available");
			excelReadWrite.writeExcelData(output,row,filename,5);
			result=false;
		}
			return result;
		}
		
public void check_cart() throws InterruptedException, IOException {
	TimeUnit.SECONDS.sleep(5);
	driver.findElement(By.id("small-cart-opener-desktop")).click();
	TimeUnit.SECONDS.sleep(3);
	driver.findElement(By.linkText("View Basket")).click();
	String filename="sleepwear.xlsx";
	excelReadWrite w=new excelReadWrite();
	String s=w.readExcelData(3,4,filename);
	TimeUnit.SECONDS.sleep(3);
	String s2=driver.findElement(By.xpath("//*[@id=\"shopping-basket-product-name-00\"]/a")).getText();
	if(s.equals(s2))
	{
		System.out.println("added to cart");
	}
	driver.findElement(By.xpath("/html/body/div[1]/main/div[2]/div[2]/div[4]/div[1]/ul/li[3]/div[5]/a")).click();
	
}
}

