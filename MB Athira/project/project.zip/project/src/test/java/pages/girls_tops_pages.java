package pages;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import baseclass.wrapperclass;
import excelutility.excelReadWrite;



public class girls_tops_pages extends wrapperclass
{
	
	public void girls_click()
	{
		driver.findElement(By.xpath("//*[@id=\"dept-girls\"]/a")).click();
	}
	public String category(int a) throws IOException, InterruptedException
	{
		String status;
		try
		{
			
		String size=null;
		excelReadWrite ex=new excelReadWrite();
		String s=ex.readExcelData(a, 0,"excel.xlsx");
		driver.findElement(By.linkText(s)).click(); //click Tops
		for(int i=1;i<4;i++)
		{
		int y=i+1;
		TimeUnit.SECONDS.sleep(2);
		s=ex.readExcelData(a, i,"excel.xlsx");
		 
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div/div[2]/div/div/div[1]/div/div["+y+"]/button")).click();  //clicking on filters 
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(By.xpath("//*[@value='"+s+"']")).click(); //selecting values
		TimeUnit.SECONDS.sleep(2);
		}
	
//		driver.findElement(By.xpath("//*[@alt='MAX Printed Semi-Sheer Extended Sleeves Top']")).click();
//		TimeUnit.SECONDS.sleep(2);
		s=ex.readExcelData(a, 4,"excel.xlsx");
		driver.findElement(By.linkText(s)).click();
		size=ex.readExcelData(a, 5,"excel.xlsx");
		
		WebElement li=driver.findElement(By.xpath("//*[@id=\"filter-form-sizes\"]"));
		//*[@id="filter-form-label-size-2"]
		System.out.println(size);
		List<WebElement> sizes=(List<WebElement>)li.findElements(By.tagName("li"));
		for(int k=0;k<sizes.size();k++)
		{System.out.println(sizes.get(k).getText());
			
			if(sizes.get(k).getText().equals(size))
			{
				System.out.println(sizes.get(k).getText());
				sizes.get(k).click();
				break;
				
			}
		}
		TimeUnit.SECONDS.sleep(2);
		
		driver.findElement(By.xpath("/html/body/div[1]/main/div/div[3]/form/div[2]/div/div[1]/fieldset/button[1]")).click();
		//driver.findElement(By.id("product-actions-btn-add")).click();
		ex.writeExcelData("Pass", a, "excel.xlsx", 6);
		status="valid";
	}
		catch(Exception e)
		{
			excelReadWrite ex=new excelReadWrite();
			ex.writeExcelData("Fail", a, "excel.xlsx", 6);
			System.out.println("Invalid data");
			status="invalid";
		}
		return status;
	}
	public void cartcheck(int b) throws IOException, InterruptedException
	{
	     TimeUnit.SECONDS.sleep(2);
		driver.findElement(By.xpath("//span[contains(text(),\"Basket\")]")).click();
		TimeUnit.SECONDS.sleep(2);
		driver.findElement(By.linkText("View Basket")).click();
		TimeUnit.SECONDS.sleep(2);
		excelReadWrite ex=new excelReadWrite();
	   String s1=ex.readExcelData(b, 4,"excel.xlsx");
		String s2=driver.findElement(By.id("shopping-basket-product-name-00")).getText();
		if(s1.equals(s2))
		{
			System.out.println("added to cart");
		}
		driver.findElement(By.xpath("/html/body/div[1]/main/div[2]/div[2]/div[4]/div[1]/ul/li[3]/div[5]/a")).click();
	}
			
	}
