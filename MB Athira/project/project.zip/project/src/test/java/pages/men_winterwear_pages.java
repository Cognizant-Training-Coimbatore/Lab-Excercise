package pages;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import baseclass.wrapperclass;
import excelutility.excelReadWrite;

public class men_winterwear_pages extends wrapperclass {
	/*WebDriver driver;
	public men_winterwear_pages(WebDriver driver)
	{
		this.driver=driver;
	}*/
	
	public String category(int a) throws InterruptedException, IOException
	{String status;
		try 
	
	{
	
		String size = null;
		excelReadWrite ex=new excelReadWrite();
		String s=ex.readExcelData(a, 0,"exceldataw.xlsx");
		driver.findElement(By.linkText(s)).click();
		for(int i=1;i<5;i++)
		{
			
		int y=i+1;
		TimeUnit.SECONDS.sleep(3);
		s=ex.readExcelData(a, i,"exceldataw.xlsx");
		if(i==3)
		{
			size=s;
		}
		driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div/div[2]/div/div/div[1]/div/div["+y+"]/button")).click();
		TimeUnit.SECONDS.sleep(1);
		driver.findElement(By.xpath("//*[@value='"+s+"']")).click();
		TimeUnit.SECONDS.sleep(1);
		}
		s=ex.readExcelData(a, 5,"exceldataw.xlsx");
		driver.findElement(By.linkText(s)).click();
		TimeUnit.SECONDS.sleep(3);
		WebElement li=driver.findElement(By.xpath("//*[@id=\"filter-form-sizes\"]"));
		
		List<WebElement> sizes=(List<WebElement>) li.findElements(By.tagName("li"));
		for(int k=0;k<sizes.size();k++)
		{
			
			if(sizes.get(k).getText().equals(size))
			{
				sizes.get(k).click();
				break;
				
			}
		}
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.xpath("/html/body/div[1]/main/div/div[3]/form/div[2]/div/div[1]/fieldset/button[1]")).click();

		
		ex.writeExcelData("pass", a, "exceldataw.xlsx", 6);
		status ="valid";
	}
	catch(Exception e)
	{
		excelReadWrite ex=new excelReadWrite();
		ex.writeExcelData("fail", a, "exceldataw.xlsx", 6);
	
		System.out.println("invalid data");
		status ="invalid";
	}
		return status;
	}
	public void cartcheck(int b) throws IOException, InterruptedException
	{TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.id("small-cart-opener-desktop")).click();
		TimeUnit.SECONDS.sleep(3);
		driver.findElement(By.linkText("View Basket")).click();
		TimeUnit.SECONDS.sleep(3);
		excelReadWrite ex=new excelReadWrite();
	String s1=ex.readExcelData(b, 5,"exceldataw.xlsx");
		String s2=driver.findElement(By.xpath("//*[@id=\"shopping-basket-product-name-00\"]/a")).getText();
		if(s1.equals(s2))
		{
			System.out.println("added to cart");
		}
		driver.findElement(By.xpath("/html/body/div[1]/main/div[2]/div[2]/div[4]/div[1]/ul/li[3]/div[5]/a")).click();
	}

}
