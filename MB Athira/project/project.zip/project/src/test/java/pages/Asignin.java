package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelutility.excelReadWrite;

public class Asignin extends wrapperclass
{
	/*WebDriver driver;
	public Asignin( WebDriver driver)
	{
		this.driver=driver;
	}*/
	public void click_signin()
	{
	WebElement sign=driver.findElement(By.id("account-actions-signin"));
	sign.click();
	}
	public boolean read_valid_details() throws Exception
	{
		boolean  result=true;
		try
		{
		excelReadWrite ex=new excelReadWrite();
		String user=ex.readExcelData(2,0,"Asignin.xlsx");
		System.out.println(user);
		driver.findElement(By.id("j_username")).sendKeys(user);
		String pwd=ex.readExcelData(2,1,"Asignin.xlsx");
		driver.findElement(By.id("j_password")).sendKeys(pwd);
		String output="pass";
		ex.writeExcelData(output,2,"Asignin.xlsx", 2);
		Thread.sleep(3000);
		}
		catch(Exception e)
		{
			excelReadWrite ee=new excelReadWrite();
			String output="fail";
			ee.writeExcelData(output,2,"Asignin.xlsx", 2);
			System.out.println("not valid data");
		}
		return result;
		
	}
	public boolean read_invalid_details() throws IOException, InterruptedException
	{
		boolean result =true;
		try
		{
		excelReadWrite ex1=new excelReadWrite();
		//String name="signin.xlsx";
		String user1=ex1.readExcelData(3,0,"Asignin.xlsx");
		driver.findElement(By.id("j_username")).sendKeys(user1);
		String pwd1=ex1.readExcelData(3,1,"Asignin.xlsx");
		driver.findElement(By.id("j_password")).sendKeys(pwd1);
		String output="pass";
		ex1.writeExcelData(output,3,"Asignin.xlsx", 2);
		Thread.sleep(3000);
		}
		catch(Exception e)
		{
			excelReadWrite e1=new excelReadWrite();
			String output="fail";
			e1.writeExcelData(output,3,"Asignin.xlsx", 2);
		}
		return result;
	}
	public boolean nousername() throws IOException, InterruptedException
	{
		boolean result=true;
		try
		{
			excelReadWrite ex2=new excelReadWrite();
		String pwd2=ex2.readExcelData(4,1,"Asignin.xlsx");
		driver.findElement(By.id("j_password")).sendKeys(pwd2);	
		String output="pass";
		ex2.writeExcelData(output,4,"Asignin.xlsx", 2);
		Thread.sleep(3000);
		}
		catch(Exception e)
		{

			excelReadWrite e2=new excelReadWrite();
			String output="fail";
			e2.writeExcelData(output,4,"Asignin.xlsx", 2);
		}
		
		return result;
		}

	public boolean nopwd() throws IOException, InterruptedException
	{
		boolean result=true;
		try
		{
			excelReadWrite ex3=new excelReadWrite();
		String user3=ex3.readExcelData(5,0,"Asignin.xlsx");
		driver.findElement(By.id("j_username")).sendKeys(user3);
		String output="pass";
		ex3.writeExcelData(output,5,"Asignin.xlsx", 2);
		Thread.sleep(3000);
		}
		catch(Exception e)
		{
			excelReadWrite e2=new excelReadWrite();
			String output="fail";
			e2.writeExcelData(output,5,"Asignin.xlsx", 2);

		}
		return result;
	}
	
	public void submit_signin() throws InterruptedException
	{
		driver.findElement(By.id("signin-form-submit")).click();
	}
	public void aftersignin() throws InterruptedException
	{
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div[1]/div/div[2]/div/div/div[2]/div[1]/div/button/span[1]/div")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div[1]/div/div[2]/div/div/div[2]/div[1]/div/div/div/div/div/div[2]/ul/a[11]/span[1]")).click();
		
	}
	public void closesignin()
	{
		
		driver.findElement(By.xpath("//*[@id=\"signup-close\"]/span/img")).click();
	}
	
}

