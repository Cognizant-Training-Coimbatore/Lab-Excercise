package stepdefinition;

import java.util.concurrent.TimeUnit;

import baseclass.wrapperclass;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.accessoriesPage;

public class accessoriesSteps extends wrapperclass
{
	
	@Given("^Click on BOYS module$")
	public void Click_on_BOYS_module() throws Throwable 
	{
		
		TimeUnit.SECONDS.sleep(3);
		accessoriesPage obj1 = new accessoriesPage();
		obj1.boyclick();
	}
	@When("^Select sub category Boys ACCESSORIES, necessary filters added, add product to cart$")
	public void select_sub_category_Boys_ACCESSORIES() throws Throwable
	{
		accessoriesPage obj1 = new accessoriesPage();
		for(int i=1;i<4;i++)
		   {
		   obj1.categoryBAcc(i);
		   }
	}
	@Then("^check if the product is present in the cart$")
	public void check_if_the_product_is_in_the_cart_acc() throws Throwable 
	{
		accessoriesPage obj2 = new accessoriesPage();
		obj2.cartcheckBAcc(3);
		//quit();
		driver.navigate().to("https://www.maxfashion.in");
	}
	
}