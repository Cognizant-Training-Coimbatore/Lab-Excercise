package stepdefinition;

import baseclass.wrapperclass;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import pages.girls_indianwear_pages;
import pages.girls_tops_pages;

public class girls_indianwear extends wrapperclass {
	
	/*@Before
	public void launch()
	{
		launchApp("chrome","https://maxfashion.in/");
	}
	@Given("^GIRLS category from max website is opened$")
	public void girls_category_in_max_website_is_opened() throws Throwable 
	{
		girls_indianwear_pages girl=new girls_indianwear_pages(driver);
		girl.girls_click();
	}*/

	@When("^I click on category Accessories,necessary filters are applied,add the product to the cart$")
	public void i_click_on_category_Tops() throws Throwable 
	{
		girls_indianwear_pages girl1=new girls_indianwear_pages();
		girl1.girls_click();

		//excelReadWrite ex=new excelReadWrite();
		girls_indianwear_pages girl=new girls_indianwear_pages();
		for(int i=1;i<4;i++)
		   {
			String status=girl.category(i);
			if(status=="invalid")
			{
				screenshot("C:\\Users\\Admin\\Desktop\\Batch 1 programs\\project\\src\\test\\resources\\screenshot\\invalid"+screen);
				screen++;
			}
		   }
	}

	
	@Then("^check if the backpack is there in the cart\\.$")
	public void check_if_the_product_is_in_the_cart() throws Throwable
	{
		girls_indianwear_pages girl=new girls_indianwear_pages();
		girl.cartcheck(3);
		extentreport("valid");
		driver.navigate().to("https://www.maxfashion.in/");
		//close();
	}

}