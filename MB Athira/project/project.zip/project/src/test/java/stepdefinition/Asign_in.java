package stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import baseclass.wrapperclass;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.Asignin;
public class Asign_in extends wrapperclass
{
	//WebDriver driver;
	
	@Given("^Open chrome and start application$")
	public void open_chrome_and_start_application()
	{
		launchApp("chrome","https://www.maxfashion.in");
		Asignin s=new Asignin();
		s.click_signin();
		
	}

	@When("^username and password is entered$")
	public void username_and_password_is_entered() throws Throwable 
	{
	    Asignin s1=new Asignin();
	    s1.read_valid_details();
		s1.submit_signin();
		Thread.sleep(4000);
		System.out.println("after signin");
		s1.aftersignin();
		Thread.sleep(2000);
		
	    System.out.println("next one");
		Asignin s2=new Asignin();
		s2.click_signin();
		s2.read_invalid_details();	
		s2.submit_signin();
		 screenshot("C:\\Users\\Admin\\Desktop\\batch 1 prgms\\Maxfashion\\src\\test\\resources\\Screenshot\\sign1");
		Thread.sleep(2000);
		s2.closesignin();
		Thread.sleep(2000);
		
		Asignin s3=new Asignin();
		s3.click_signin();
		s3.nopwd();		 
		s3.submit_signin();
		screenshot("C:\\Users\\Admin\\Desktop\\batch 1 prgms\\Maxfashion\\src\\test\\resources\\Screenshot\\sign2");
		Thread.sleep(2000);
		s3.closesignin();
		Thread.sleep(2000);
		
	    
		Asignin s4=new Asignin();
		s4.click_signin();
		s3.nousername();
		s4.submit_signin();
		 screenshot("C:\\Users\\Admin\\Desktop\\batch 1 prgms\\Maxfashion\\src\\test\\resources\\Screenshot\\sign3");
		Thread.sleep(2000);
		s4.closesignin();
		Thread.sleep(2000);
		
	}

	@Then("^user should be able to sign in to the application$")
	public void user_should_be_able_to_sign_in_to_the_application() throws Throwable
	{
		
	   System.out.println("user is sign in to the page");
	   
	}
	

}
