package stepdefinition;

import java.util.concurrent.TimeUnit;

import baseclass.wrapperclass;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.men_loungewear_pages;
import pages.men_sportswear_pages;
import pages.men_winterwear_pages;

public class men_loungewear extends wrapperclass{
	@When("^I click on menloungewear category,necessary filters are applied,add the product to the cart$")
	public void i_click_on_winterwear_category() throws Throwable {
		//System.out.println("hhhhh"+driver);
		men_sportswear_pages men=new men_sportswear_pages();
		men.mens_click();
		TimeUnit.SECONDS.sleep(2);
		men_loungewear_pages menl=new men_loungewear_pages();
		for(int i=1;i<4;i++)
			{
			String status=menl.category(i);
			if(status=="invalid")
			{
				screenshot("C:\\Users\\Admin\\Desktop\\batch 1 programs\\project\\src\\test\\resources\\screenshot\\invalid"+screen);
				screen++;
			}
			}
			
	   TimeUnit.SECONDS.sleep(3);
	   //System.out.println("hhhhh222"+driver);
	   
	}

	@Then("^check if the menloungewear product is there inside the cart$")
	public void check_if_the_product_is_there_in_the_cart() throws Throwable {
		 men_loungewear_pages menl=new men_loungewear_pages();
		menl.cartcheck(3);
		extentreport("valid");
		//System.out.println("dss"+driver);
		 //close();
	}


}
