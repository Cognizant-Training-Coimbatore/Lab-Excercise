package stepdefinition;


import baseclass.wrapperclass;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.accessoriesPage;
import pages.boys_ww_page;

public class boys_wwSteps extends wrapperclass
{
	@When("^Select sub category Boys Winterwear, necessary filters added, add product to cart$")
	public void select_sub_category_Boys_ww() throws Throwable
	{
		accessoriesPage obj1 = new accessoriesPage();
		obj1.boyclick();
		boys_ww_page obj2 = new boys_ww_page();
		for(int i=1;i<4;i++)
		   {
			obj2.categoryBWw(i);
		   }
	}
	@Then("^check if the Boys Winterwear product is present in the cart$")
	public void check_if_the_product_is_in_the_cart_ww() throws Throwable 
	{
		boys_ww_page obj1 = new boys_ww_page();
		obj1.cartcheckBWw(3);
		
	}
}
