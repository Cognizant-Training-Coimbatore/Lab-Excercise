package stepdefinition;

import java.util.concurrent.TimeUnit;

import baseclass.wrapperclass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.shoes_page;
import pages.sleepwear_pages;


public class sleepwear extends wrapperclass {
	static int no;
	

	
	@When("^I click on sleepwear category,neccesary filters are applied ,add the product to cart$")
	public void i_click_on_sleepwear_category_neccesary_filters_are_applied_add_the_product_to_cart() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    sleepwear_pages t=new sleepwear_pages();
	    t.categorysleepwear_click();
	    for(int i=1;i<=3;i++) {
	    	TimeUnit.SECONDS.sleep(3);
	    	boolean b=t.filter(i);
	    	 if(b==false) {
					screenshot("C:\\Users\\Admin\\Desktop\\project\\src\\test\\resources\\screenshot\\testsleepwear"+no+".jpg");
					no++;
					//driver.navigate().to("https://www.maxfashion.in/in/en/c/maxwomen-sleepwear");
				}
	    }
	   
	    
	}

	@Then("^check if sleepwear product will be there in the cart$")
	public void check_if_sleepwear_product_will_be_there_in_the_cart() throws Throwable {
		 sleepwear_pages t=new sleepwear_pages();
		Thread.sleep(5000);
		   t.check_cart();
		   //quit();
		   driver.navigate().to("https://www.maxfashion.in");
	}


}