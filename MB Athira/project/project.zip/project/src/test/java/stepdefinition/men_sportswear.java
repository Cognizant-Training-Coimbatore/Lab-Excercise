package stepdefinition;

import java.util.concurrent.TimeUnit;

import baseclass.wrapperclass;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import excelutility.excelReadWrite;
import pages.men_sportswear_pages;

public class men_sportswear extends wrapperclass
{
	
	/*@Before
	public void launch()
	{
		launchApp("chrome","https://www.maxfashion.in/");
	}*/
	
	@Given("^mens category from max website is opened$")
	public void mens_category_from_max_website_is_opened() throws Throwable 
	{
		//launchApp("chrome","https://www.maxfashion.in/");
		TimeUnit.SECONDS.sleep(3);
		men_sportswear_pages men=new men_sportswear_pages();
		men.mens_click();
	}

	@When("^I click on mensportswear category,necessary filters are applied,add the product to the cart$")
	public void i_click_on_sportswear_category() throws Throwable {
		
	   men_sportswear_pages men=new men_sportswear_pages();
	  
	   for(int i=1;i<4;i++)
		   {
		   String status=men.category(i);
		   if(status=="invalid")
			{
				screenshot("C:\\Users\\Admin\\Desktop\\batch 1 programs\\project\\src\\test\\resources\\screenshot\\invalid"+screen);
				screen++;
				
			}
		   }
	   //TimeUnit.SECONDS.sleep(3);
	   
	   
	}

	@Then("^check if the mensportswear product is there in the cart$")
	public void check_if_the_product_is_there_in_the_cart() throws Throwable {
		 men_sportswear_pages men=new men_sportswear_pages();
		 men.cartcheck(3);
		 extentreport("valid");
		 driver.navigate().to("https://www.maxfashion.in/");
		 //close();
		 
	}

}
