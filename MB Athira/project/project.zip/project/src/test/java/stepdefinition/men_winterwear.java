package stepdefinition;

import java.util.concurrent.TimeUnit;

import baseclass.wrapperclass;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.men_sportswear_pages;
import pages.men_winterwear_pages;

public class men_winterwear extends wrapperclass{
	
	/*@Before
	public void launch()
	{
		launchApp("chrome","https://www.maxfashion.in/");
	}
	@Given("^mens category from max website is opened$")
	public void mens_category_from_max_website_is_opened() throws Throwable 
	{
		men_sportswear_pages men=new men_sportswear_pages(driver);
		men.mens_click();
	}
*/
	@When("^I click on menwinterwear category,necessary filters are applied,add the product to the cart$")
	public void i_click_on_winterwear_category() throws Throwable {
		//System.out.println("hhhhh"+driver);
		men_sportswear_pages men=new men_sportswear_pages();
		men.mens_click();
		TimeUnit.SECONDS.sleep(2);
		men_winterwear_pages menw=new men_winterwear_pages();
		
		for(int i=1;i<4;i++)
			{
			String status=menw.category(i);
			if(status=="invalid")
			{
				screenshot("C:\\Users\\Admin\\Desktop\\batch 1 programs\\project\\src\\test\\resources\\screenshot\\invalid"+screen);
				screen++;
			}
			}
			
	   TimeUnit.SECONDS.sleep(3);
	   //System.out.println("hhhhh222"+driver);
	   
	}

	@Then("^check if the menwinterwear product is there inside the cart$")
	public void check_if_the_product_is_there_in_the_cart() throws Throwable {
		 men_winterwear_pages menw=new men_winterwear_pages();
		menw.cartcheck(3);
		extentreport("valid");
		driver.navigate().to("https://www.maxfashion.in/");
		//System.out.println("dss"+driver);
		 //close();
	}

	
}
