package stepdefinition;

import java.util.concurrent.TimeUnit;

import baseclass.wrapperclass;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.shoes_page;



public class shoes extends wrapperclass {
	static int no;
	/*@Before
	public void test1() {
		
		// TODO Auto-generated method stub
		launchApplication("chrome","https://www.maxfashion.in");
	}*/


	@Given("^women category from max website is opened$")
	public void women_category_from_max_website_is_opened() throws Throwable {
		//launchApp("chrome","https://www.maxfashion.in");
		shoes_page t=new shoes_page();
	  
	   
	   t.women_click();
	   
	  
	}
	@When("^I click on shoes category,neccesary filters are applied ,add the product to cart$")
	public void i_click_on_top_category() throws Throwable {
		shoes_page t=new shoes_page(); 
		t.shoes_click();
		for(int i=1;i<=3;i++) {
			TimeUnit.SECONDS.sleep(3);
			boolean m=t.filter_shoes(i);
			if(m==false) {
				screenshot("C:\\Users\\Admin\\Desktop\\project\\src\\test\\resources\\screenshot\\test"+no+".jpg");
				no++;
			}
		}
		
		

	}

	@Then("^check if product is there in the cart$")
	public void check_if_product_is_there_in_the_cart() throws Throwable {
	shoes_page t=new shoes_page(); 
	t.check_cart();
	driver.navigate().to("https://www.maxfashion.in");
	//quit();
		
		
	}

}
