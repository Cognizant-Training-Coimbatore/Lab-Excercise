package stepdefinition;

import baseclass.wrapperclass;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.tops_pages;

public class top extends wrapperclass {
	   public static int no;
	/*@Before
	public void test1() {
		
		// TODO Auto-generated method stub
		launchApplication("chrome","https://www.maxfashion.in");
	}

		

	@Given("^women category from max website is opened$")
	public void women_category_from_max_website_is_opened() throws Throwable {
	   tops_pages t=new tops_pages(driver);
	  
	   
	   t.women_click();
	   
	  
	}*/

	@When("^I click on top category,neccesary filters are applied ,add the product to cart$")
	public void i_click_on_top_category() throws Throwable {
		tops_pages t=new tops_pages();
	   Thread.sleep(5000);
	   t.category_click();
	   Thread.sleep(5000);
	   for(int i=1;i<=3;i++) {
		  boolean b= t.filter(i);
				if(b==false) {
					screenshot("C:\\Users\\Admin\\Desktop\\project\\src\\test\\resources\\screenshot\\testtop"+no+".jpg");
					no++;
				}
		   
	   }

	}

	@Then("^check if product will be there in the cart$")
	public void check_if_product_is_there_in_the_cart() throws Throwable {
		tops_pages t=new tops_pages();
		   Thread.sleep(5000);
		   t.check_cart();
		   close();
		  
	}
	
}
