package stepdefinition;

import java.util.concurrent.TimeUnit;

import baseclass.wrapperclass;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import pages.girls_tops_pages;

public class girls_tops extends wrapperclass
{
	
	/*@Before
	public void launch()
	{
		launchApp("chrome","https://maxfashion.in/");
	}*/
	@Given("^GIRLS category from max website is opened$")
	public void girls_category_in_max_website_is_opened() throws Throwable 
	{
		//launchApp("chrome","https://maxfashion.in/");
		girls_tops_pages girl=new girls_tops_pages();
		girl.girls_click();
	}

	@When("^I click on category Tops,necessary filters are applied,add the product to the cart$")
	public void i_click_on_category_Tops() throws Throwable 
	{
		//excelReadWrite ex=new excelReadWrite();
		girls_tops_pages girl=new girls_tops_pages();
		for(int i=1;i<4;i++)
		   {
			String status=girl.category(i);
			   if(status=="invalid")
				{
					screenshot("C:\\Users\\Admin\\Desktop\\Batch1 programs\\Project\\src\\test\\resources\\screenshot\\invalid"+screen);
					screen++;
					
				}
		   }
	}

	
	@Then("^check if the Tops is in the cart\\.$")
	public void check_if_the_product_is_in_the_cart() throws Throwable
	{
		girls_tops_pages girl=new girls_tops_pages();
		girl.cartcheck(3);
		 extentreport("valid");
		 driver.navigate().to("https://www.maxfashion.in/");
		//close();
	}



}