package baseclass;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class wrapperclass 
{
	public static int screen=0,extend=1;
public static WebDriver driver;
public void launchApp(String browser, String url)
{
	if(browser.equals("chrome"))
	{
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");
		options.addArguments("--disable-notifications");
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Desktop\\batch 1 programs\\project\\src\\test\\resources\\driver\\chromedriver.exe");
		driver=new ChromeDriver(options);
		driver.get(url);
	}
	if(browser.equals("firefox"))
	{
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\Admin\\Desktop\\batch 1 programs\\project\\src\\test\\resources\\driver\\geckodriver.exe");
		driver=new FirefoxDriver();
		driver.get(url);
	}
}
public void screenshot(String path) throws IOException 
{
	TakesScreenshot ts=((TakesScreenshot)driver);
	File Source=ts.getScreenshotAs(OutputType.FILE);
	FileUtils.copyFile(Source,new File(path));
}
public void extentreport(String status1)
{
	String statuses=status1;
	ExtentReports extent;
	ExtentTest logger;
	extent=new ExtentReports("C:\\Users\\Admin\\Desktop\\batch 1 programs\\project\\src\\test\\resources\\extentreport\\MyReport"+extend+".html",true);
	logger=extent.startTest("test1");
	extend++;
	if(statuses.equals("valid"))
	{
		logger.log(LogStatus.PASS,"Test is pass");
	}
	else
	{
		logger.log(LogStatus.FAIL,"Test is failed");
	}
	//driver.quit();
	extent.flush();
	extent.endTest(logger);
	extent.close();
}
public void close()
{
	driver.quit();
}
}
