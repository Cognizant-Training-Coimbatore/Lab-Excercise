package excelutility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excelReadWrite {
	
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	FileInputStream inputStream;
	FileOutputStream outputStream;
		
	//To read excel data
	public String readExcelData(int rowNumber, int colNumber,String excelfile) throws IOException 
	{String path="C:\\Users\\Admin\\Desktop\\batch 1 programs\\project\\src\\test\\resources\\testdata\\";
	inputStream= new FileInputStream(new File(path+excelfile));

		//inputStream = new FileInputStream(new File("C:\\Users\\Admin\\Desktop\\batch 1 programs\\project\\src\\test\\resources\\testdata\\"+excelfile+".xlsx"));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet("Sheet1");	
		
		XSSFRow row = sheet.getRow(rowNumber);
		XSSFCell cell = row.getCell(colNumber);
		
		String value = cell.getStringCellValue();
		return value;
	}
	
	//To write excel data
	/*public void writeExcelData(String data) throws IOException
	{
		inputStream = new FileInputStream(new File("C:\\Users\\Admin\\Desktop\\batch 1 programs\\project\\src\\test\\resources\\testdata\\exceldata.xlsx"));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet("Sheet1");	
		
		int maxRow = sheet.getLastRowNum() + 1;
		int cellnum = 0;
		
		XSSFRow row = sheet.createRow(maxRow);
		XSSFCell cell = row.createCell(cellnum++);
		cell.setCellValue(data);
		
		inputStream.close();
		
		outputStream = new FileOutputStream(new File("C:\\Users\\Admin\\Desktop\\batch 1 programs\\project\\src\\test\\resources\\testdata\\exceldata.xlsx"));
		workbook.write(outputStream);
        outputStream.close();
	}
	*/
	public static void writeExcelData(String data,int row1,String filename,int cellnum) throws IOException
	{
	String path="C:\\Users\\Admin\\Desktop\\batch 1 programs\\project\\src\\test\\resources\\testdata\\";
	FileInputStream fs= new FileInputStream(new File(path+filename));

	@SuppressWarnings("resource")
	XSSFWorkbook wk = new XSSFWorkbook(fs);
	XSSFSheet sh = wk.getSheet("Sheet1"); 



	//create the row 
	XSSFRow row = sh.getRow(row1);
	//int cellnum=row.getLastCellNum();
	//create cell
	XSSFCell cell = row.createCell(cellnum);
	//enter value in cell
	cell.setCellValue(data);

	fs.close();

	FileOutputStream fk = new FileOutputStream(new File(path+filename));
	wk.write(fk);
	        fk.close();
	}


}