package runner;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class testcase extends wrapperclass
{
	 static Logger log = Logger.getLogger(testcase.class.getName());
	ExcelReadWrite wc=new ExcelReadWrite();
	WebElement home,export,acccookies,result,searchopen,search,fproduct,quest,addtobag,mybag,max,min,prize;
	String product,prod,hometitle,searchtitle,prodstring,prodname,prodprice,porf="Fail",showing;
	int i,j=1,s=1,pf,k,pr;
	@Given("^I am on the homepage to do a single keyword search$")
	public void i_am_on_the_homepage_to_do_a_single_keyword_search() throws Throwable {
		DOMConfigurator.configure("log4j.xml");
		launch("chrome","https://www.lego.com/en-us");
		log.info("browser launched");
		System.out.println("Single keyword search commensing");
		log.info("Single keyword search commensing");
		export=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[5]/div/div[1]/div/button"));
		export.click();
		acccookies=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div[2]/button"));
		acccookies.click();
		log.info("Cookies accepted");
	}

	@When("^I do a single keyword search for \\(\\.\\.\\.\\)$")
	public void i_do_a_single_keyword_search_for() throws Throwable {
		for(i=1;i<=5;i++)
		{
	    searchopen=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/header/div/div[2]/div/div/button[1]"));
	    searchopen.click();
	    log.info("Search button clicked");
		product=wc.readExcelData(i);
		log.info("Product no:"+i+" is read from the excel sheet");
		search=driver.findElement(By.id("search-input"));
		search.sendKeys(product);
		log.info("Product entered into search box");
		search.submit();
		log.info("Product submitted into search");
		result=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[1]/h3/span/span"));
		log.info("Search result shown");
		prod=result.getText();
		prodstring=prod.replace('"','#').replaceAll("#", "");
		System.out.println(prodstring);
		if(prodstring.contentEquals(product))
		{
			log.info("Single keyword search is done");
			System.out.println("Single keyword search is done for "+product);
			wc.writeExcelData("Single keyword search is done", i,5);
			log.info("Result written to excel sheet");
			j++;
		}
		else
		{
			log.info("Single keyword search is not done");
			System.out.println("Single keyword search is not done for "+product);
		}
		Thread.sleep(1000);
		fproduct=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/div/ul/li[1]/div/div[2]/div[1]/a/h2/span"));
		fproduct.click();
		log.info("First product is clicked");
		Thread.sleep(2000);
		try
		{
			quest=driver.findElement(By.xpath("//*[@id=\"noButton\"]"));
			quest.click();
			log.info("Questionnaire pop-up rejected");
		}
		catch(Exception e)
		{}
		Thread.sleep(1000);
		prodname=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/h1/span")).getText();
		log.info("Product name is extracted");
		prodprice=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/div[5]/div/span")).getText();
		log.info("Product name is extracted");
		System.out.println(prodname);
		System.out.println(prodprice);
		max=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[1]/div/div/div/div[1]/div/button/div[1]"));
		max.click();
		log.info("Image maximised");
		Thread.sleep(2000);
		screenshot("C://Users//Admin//Pictures//Screenshots//"+prodstring+".PNG");
		log.info("Screenshot is taken");
		min=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[1]/div/div[3]/div/div/div/div[1]/div/button/div"));
		min.click();
		log.info("Image minimised");
		Thread.sleep(2000);
		try
		{
			addtobag=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/div[6]/div[1]/div[2]/button"));
			addtobag.click();
		}
		catch(Exception e) 
		{
			List <WebElement>add=driver.findElements(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/div[*]/div[1]/div[2]/button"));
			for(WebElement add1:add)
			{
				add1.click();
				break;
			}
		}
		log.info("Product added to bag");
		try
		{
		home=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div/ol/li[1]/a/span/span"));
		Thread.sleep(2000);
		home.click();
		}
		catch(Exception e)
		{
			driver.navigate().back();
			driver.navigate().back();
		}
		log.info("Navigated to home");
		Thread.sleep(3000);
		}
		System.out.println();
		log.info("");
	}

	@Then("^I see a single keyword search result page with more than zero results$")
	public void i_see_a_single_keyword_search_result_page_with_more_than_zero_results() throws Throwable {
		if(j==6)
		{
			porf="Pass";
		}
		log.info("Test "+porf+"ed");
		System.out.println("Single keyword search "+porf+"ed");
		wc.writeExcelData(porf,1,6);
		log.info("Test status written to excel sheet");
		//mybag=driver.findElement(By.xpath("//*[@id="root"]/div/div[2]/header/div/div[1]/nav/ul[2]/li[3]/a");
		//mybag.click();
		quit();
		log.info("Browser quitted");
		log.info("");
	}

	@Given("^I am on the homepage to do a multiple keywords search$")
	public void i_am_on_the_homepage_to_do_a_multiple_keywords_search() throws Throwable {
		DOMConfigurator.configure("log4j.xml");
		launch("chrome","https://www.lego.com/en-us");
		log.info("browser launched");
		System.out.println("Multiple keywords search commensing");
		log.info("Multiple keywords search commensing");
		export=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[5]/div/div[1]/div/button"));
		export.click();
		acccookies=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div[2]/button"));
		acccookies.click();
		log.info("Cookies accepted");
	}

	@When("^I do a multiple keyword search for \\(\\.\\.\\. \\.\\.\\.\\)$")
	public void i_do_a_multiple_keyword_search_for() throws Throwable {
		j=6;
		porf="Fail";
		for(i=6;i<=10;i++)
		{
	    searchopen=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/header/div/div[2]/div/div/button[1]"));
	    searchopen.click();
	    log.info("Search button clicked");
		product=wc.readExcelData(i);
		log.info("Product no:"+i+" is read from the excel sheet");
		search=driver.findElement(By.id("search-input"));
		search.sendKeys(product);
		log.info("Product entered into search box");
		search.submit();
		log.info("Product submitted into search");
		result=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[1]/h3/span/span"));
		log.info("Search result shown");
		prod=result.getText();
		prodstring=prod.replace('"','#').replaceAll("#", "");
		System.out.println(prodstring);
		if(prodstring.contentEquals(product))
		{
			log.info("Multiple keyword search is done");
			System.out.println("Multiple keyword search is done for "+product);
			wc.writeExcelData("Multiple keyword search is done", i,5);
			log.info("Result written to excel sheet");
			j++;
		}
		else
		{
			log.info("Multiple keyword search is not done");
			System.out.println("Multiple keyword search is not done for "+product);
		}
		Thread.sleep(1000);
		fproduct=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/div/ul/li[1]/div/div[2]/div[1]/a/h2/span"));
		fproduct.click();
		log.info("First product is clicked");
		Thread.sleep(2000);
		try
		{
			quest=driver.findElement(By.xpath("//*[@id=\"noButton\"]"));
			quest.click();
			log.info("Questionnaire pop-up rejected");
		}
		catch(Exception e)
		{}
		Thread.sleep(1000);
		prodname=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/h1/span")).getText();
		log.info("Product name is extracted");
		prodprice=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/div[5]/div/span")).getText();
		log.info("Product name is extracted");
		System.out.println(prodname);
		System.out.println(prodprice);
		max=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[1]/div/div/div/div[1]/div/button/div[1]"));
		max.click();
		log.info("Image maximised");
		Thread.sleep(2000);
		screenshot("C://Users//Admin//Pictures//Screenshots//"+prodstring+".PNG");
		log.info("Screenshot is taken");
		min=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[1]/div/div[3]/div/div/div/div[1]/div/button/div"));
		min.click();
		log.info("Image minimised");
		Thread.sleep(2000);
		try
		{
			addtobag=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/div[6]/div[1]/div[2]/button"));
			addtobag.click();
		}
		catch(Exception e) 
		{
			List <WebElement>add=driver.findElements(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/div[*]/div[1]/div[2]/button"));
			for(WebElement add1:add)
			{
				add1.click();
				break;
			}
		}
		log.info("Product added to bag");
		try
		{
		home=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div/ol/li[1]/a/span/span"));
		Thread.sleep(2000);
		home.click();
		}
		catch(Exception e)
		{
			driver.navigate().back();
			driver.navigate().back();
		}
		log.info("Navigated to home");
		Thread.sleep(3000);
		}
		System.out.println();
		log.info("");
	}

	@Then("^I see multiple keyword search result page with more than zero results$")
	public void i_see_multiple_keyword_search_result_page_with_more_than_zero_results() throws Throwable {
		if(j==11)
		{
			porf="Pass";
		}
		log.info("Test "+porf+"ed");
		System.out.println("Multiple keyword search "+porf+"ed");
		wc.writeExcelData(porf,1,6);
		log.info("Test status written to excel sheet");
		//mybag=driver.findElement(By.xpath("//*[@id="root"]/div/div[2]/header/div/div[1]/nav/ul[2]/li[3]/a");
		//mybag.click();
		quit();
		log.info("Browser quitted");
		log.info("");
	}

	@Given("^I have done a search using a valid search term$")
	public void i_have_done_a_search_using_a_valid_search_term() throws Throwable {
		DOMConfigurator.configure("log4j.xml");
		launch("chrome","https://www.lego.com/en-us");
		log.info("browser launched");
		System.out.println("Search sorting commensing");
		export=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[5]/div/div[1]/div/button"));
		export.click();
		acccookies=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div[2]/button"));
		acccookies.click();
		log.info("Cookies accepted");
		searchopen=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/header/div/div[2]/div/div/button[1]"));
		searchopen.click();
		log.info("Search button clicked");
		product="Iron man";
		log.info("Keyword assigned");
		search=driver.findElement(By.id("search-input"));
		search.sendKeys(product);
		log.info("Product entered into search box");
		search.submit();
		log.info("Product submitted into search");
		result=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[1]/h3/span/span"));
		log.info("Search result shown");
		prod=result.getText();
		prodstring=prod.replace('"','#').replaceAll("#", "");
		System.out.println(prodstring);
		if(prodstring.contentEquals(product))
		{
			System.out.println("Valid keyword search is done");
			log.info("Search is done");
		}
		else
		{
			System.out.println("Search is not done for a valid keyword");
			log.info("Search is not done");
		}
		Thread.sleep(1000);
	}
	@Given("^I see a certain amount of items$")
	public void i_see_a_certain_amount_of_items() throws Throwable {
		DOMConfigurator.configure("log4j.xml");
		showing=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/div/div[2]/div[1]/span")).getText().split(" ")[5];
		pf=Integer.parseInt(showing);
		log.info("Extracted the number of search results");
		System.out.println(pf);
	}

	@When("^I filter on \\(PRIZE\\)$")
	public void i_filter_on_PRIZE() throws Throwable {
		for(int k=1;k<=5;k++)
	    {
	    	WebElement prize=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/aside/div/div/div[4]/div/div/div/ul/li["+k+"]/label/span"));
	    	prize.click();
	    	log.info("Prize no:"+k+" on the sort list is clicked");
	    	Thread.sleep(2000);
	    	showing=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/div/div[2]/div[1]/span")).getText().split(" ")[5];
	    	int pr=Integer.parseInt(showing);
			if(pr<pf)
			{
				System.out.println("Sort is done successfully with price number "+k+" on the list");
				log.info("Sorting is done");
				System.out.println(pr);
				wc.writeExcelData("The results are filtered to display a smaller amount of items",(k+10),5);
				log.info("Sort result is written into the excel sheet");
				s++;
			}
			else
			{
				System.out.println("Sort is done unsuccessfully with price number "+k+" on the list");
				log.info("Sorting is not done");
			}
			driver.navigate().refresh();
			log.info("Page is refreshed");
	    }
		log.info("");
	}

	@Then("^The results are filtered to display a smaller amount of items$")
	public void the_results_are_filtered_to_display_a_smaller_amount_of_items() throws Throwable {
		if(s==6)
		{
			porf="Pass";
		}
		log.info("Test "+porf+"ed");
		System.out.println("Sorting "+porf+"ed");
		wc.writeExcelData(porf,11,6);
		log.info("Test status written to excel sheet");
		quit();
		log.info("Browser quitted");
		log.info("");
	}

}
