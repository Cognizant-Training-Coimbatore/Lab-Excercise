package runner;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class scenario1 extends wrapperclass
{

	static WebElement home,export,acccookies,result,searchopen,search,fproduct,quest,addtobag,mybag,max,min;
	static String product,prod,hometitle,searchtitle,prodstring,prodname,prodprice,porf="Fail";
	static int i,j=0,pf,pr,s=1,k;
	static ExcelReadWrite wc=new ExcelReadWrite();
	public static void main(String[] args) throws InterruptedException, IOException 
	{
		launch("chrome","https://www.lego.com/en-us");
		System.out.println("Sorting the search commensing");
		export=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[5]/div/div[1]/div/button"));
		export.click();
		acccookies=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div[2]/button"));
		acccookies.click();
		searchopen=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/header/div/div[2]/div/div/button[1]"));
		searchopen.click();
		product="Iron man";
		search=driver.findElement(By.id("search-input"));
		search.sendKeys(product);
		search.submit();
		result=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[1]/h3/span/span"));
		prod=result.getText();
		prodstring=prod.replace('"','#').replaceAll("#", "");;
		System.out.println(prodstring);
		if(prodstring.contentEquals(product))
		{
			System.out.println("Search is done for "+product);
		}
		else
		{
			System.out.println("Search is not done for "+product);
		}
		Thread.sleep(1000);
		String showing=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/div/div[2]/div[1]/span")).getText().split(" ")[5];
		pf=Integer.parseInt(showing);
		System.out.println(pf);
		for(k=1;k<=5;k++)
	    {
	    	WebElement prize=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/aside/div/div/div[4]/div/div/div/ul/li["+k+"]/label/span"));
	    	prize.click();
	    	Thread.sleep(2000);
	    	showing=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/div/div[2]/div[1]/span")).getText().split(" ")[5];
	    	pr=Integer.parseInt(showing);
			if(pr<pf)
			{
				System.out.println("Sort is done successfully with price number "+k+" on the list");
				System.out.println(pr);
				wc.writeExcelData("The results are filtered to display a smaller amount of items",(k+10),5);
				s++;
			}
			else
			{
				System.out.println("Sort is done unsuccessfully with price number "+k+" on the list");
			}
			driver.navigate().refresh();
			//driver.navigate().to("https://www.lego.com/en-us/search?q=Iron%20man");
	    }
		if(s==6)
		{
			porf="Pass";
		}
		System.out.println(porf);
		wc.writeExcelData(porf,11,6);
	}

}
