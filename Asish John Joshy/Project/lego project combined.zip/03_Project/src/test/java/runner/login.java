 package runner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

public class login
{
	WebDriver driver;
	Actions action;
	
	//constructor
	public login(WebDriver driver)
	{
		this.driver=driver;
	}
						
	By account= By.xpath("//*[@id=\"root\"]/div/div[2]/header/div/div[1]/nav/ul[2]/li[1]/button");
	By signin=By.xpath("//button[@type=\"submit\" and text()='Sign In']");
	By username=By.xpath("//*[@id=\"username\"]");
	By password=By.xpath("//*[@id=\"password\"]");
	By enter=By.xpath("//*[@id=\"loginBtn\"]");
	By logout=By.xpath("//span[contains(.,\"Log out\")]");
	
	public void account()
	{
		driver.findElement(account).click();
	}
	
	public void signIn()
	{
		driver.findElement(signin).click();
	}
	
	public void username(String data)
	{
		driver.findElement(username).clear();
		driver.findElement(username).sendKeys(data);
	}
	public void password(String data)
	{
		driver.findElement(password).clear();
		driver.findElement(password).sendKeys(data);
	}
	public void enter()
	{
		driver.findElement(enter).click();
	}
	public void logout()
	{
		driver.findElement(logout).click();
	}
	

}
