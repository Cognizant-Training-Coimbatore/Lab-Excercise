package runner;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_data 
{
		XSSFWorkbook workbook;
		XSSFSheet sheet;
		FileInputStream inputStream;
		FileOutputStream outputStream;
			
		//To read excel data
		
		public String readExcelData(int rowNumber, int colNumber,int sheetNo) throws IOException 
		{
			inputStream = new FileInputStream(new File("C:\\Users\\Admin\\eclipse-workspace\\03_Project\\Lego_prject.xlsx"));
			
			workbook = new XSSFWorkbook(inputStream);
			sheet = workbook.getSheet("Sheet"+sheetNo);	
			
			XSSFRow row = sheet.getRow(rowNumber);
			XSSFCell cell = row.getCell(colNumber);
			
			String value = cell.getStringCellValue();
			return value;
		}
		
		//To write excel data
		public void writeExcelData(String data,int rowNo,int col, int sheetNo) throws IOException
		{
			inputStream = new FileInputStream(new File("C:\\Users\\Admin\\eclipse-workspace\\03_Project\\Lego_prject.xlsx"));
			
			workbook = new XSSFWorkbook(inputStream);
			sheet = workbook.getSheet("Sheet"+sheetNo);	
			
			XSSFRow row = sheet.getRow(rowNo);
			XSSFCell cell = row.createCell(col);
			cell.setCellValue(data);
			
			
			inputStream.close();
			
			outputStream = new FileOutputStream(new File("C:\\Users\\Admin\\eclipse-workspace\\03_Project\\Lego_prject.xlsx"));
			workbook.write(outputStream);
	        outputStream.close();
	      
		}

}
