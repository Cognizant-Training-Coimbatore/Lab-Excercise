package runner;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadWrite 
{
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	FileInputStream inputStream;
	FileOutputStream outputStream;
	XSSFRow row,row1;
	XSSFCell cell,cell1;
		
	//To read excel data
	public String readExcelData(int rowNumber) throws IOException 
	{
		inputStream = new FileInputStream(new File("C:\\Users\\Admin\\eclipse-workspace\\01_Project\\Testdata.xlsx"));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet("Sheet1");
		int colNumber=3;
		row = sheet.getRow(rowNumber);
		cell = row.getCell(colNumber);
		
		String value = cell.getStringCellValue();
		return value;
	}
	
	//To write excel data
	public void writeExcelData(String data,int rowNumber,int colNumber) throws IOException
	{
		inputStream = new FileInputStream(new File("C:\\Users\\Admin\\eclipse-workspace\\01_Project\\Testdata.xlsx"));
		
		workbook = new XSSFWorkbook(inputStream);
		sheet = workbook.getSheet("Sheet1");	
		
		//int maxRow = sheet.getLastRowNum() + 1;
		//int cellnum = 0;
		
		row1 = sheet.getRow(rowNumber);
		cell1 = row1.createCell(colNumber);
		cell1.setCellValue(data);
		
		inputStream.close();
		
		outputStream = new FileOutputStream(new File("C:\\Users\\Admin\\eclipse-workspace\\01_Project\\Testdata.xlsx"));
		workbook.write(outputStream);
        outputStream.close();
	}
	
}