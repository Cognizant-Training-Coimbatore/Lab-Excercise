package runner;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class testcase2 extends wrapperclass {
	static Logger log = Logger.getLogger(testcase.class.getName());
	ExcelReadWrite wc=new ExcelReadWrite();
	WebElement home,export,acccookies,result,searchopen,search,fproduct,quest,addtobag,mybag,max,min,prize;
	String product,prod,hometitle,searchtitle,prodstring,prodname,prodprice,porf="Fail",showing;
	int i,j=1,s=1,pf,k,pr;

	@When("^I filter on \\(PRIZE\\)$")
	public void i_filter_on_PRIZE() throws Throwable {
		DOMConfigurator.configure("log4j.xml");
		//driver.navigate().to("https://www.lego.com/en-us");
		log.info("browser launched");
		System.out.println("Search sorting commensing");
		try
		{
		export=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[5]/div/div[1]/div/button"));
		export.click();
		acccookies=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div[2]/button"));
		acccookies.click();
		log.info("Cookies accepted");
		}
		catch(Exception e)
		{}
		searchopen=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/header/div/div[2]/div/div/button[1]"));
		searchopen.click();
		log.info("Search button clicked");
		product="Iron man";
		log.info("Keyword assigned");
		search=driver.findElement(By.id("search-input"));
		search.sendKeys(product);
		log.info("Product entered into search box");
		TimeUnit.SECONDS.sleep(2);
		search.submit();
		log.info("Product submitted into search");
		result=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[1]/h3/span/span"));
		log.info("Search result shown");
		prod=result.getText();
		prodstring=prod.replace('"','#').replaceAll("#", "");
		System.out.println(prodstring);
		if(prodstring.contentEquals(product))
		{
			System.out.println("Valid keyword search is done");
			log.info("Search is done");
		}
		else
		{
			System.out.println("Search is not done for a valid keyword");
			log.info("Search is not done");
		}
		TimeUnit.SECONDS.sleep(3);
		showing=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/div/div[2]/div[1]/span")).getText().split(" ")[5];
		pf=Integer.parseInt(showing);
		log.info("Extracted the number of search results");
		System.out.println(pf);
		for(int k=1;k<=5;k++)
	    {
	    	WebElement prize=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/aside/div/div/div[4]/div/div/div/ul/li["+k+"]/label/span"));
	    	prize.click();
	    	log.info("Prize no:"+k+" on the sort list is clicked");
	    	TimeUnit.SECONDS.sleep(2);
	    	showing=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/div/div[2]/div[1]/span")).getText().split(" ")[5];
	    	int pr=Integer.parseInt(showing);
			if(pr<pf)
			{
				System.out.println("Sort is done successfully with price number "+k+" on the list");
				log.info("Sorting is done");
				System.out.println(pr);
				wc.writeExcelData("The results are filtered to display a smaller amount of items",(k+10),5);
				log.info("Sort result is written into the excel sheet");
				s++;
			}
			else
			{
				System.out.println("Sort is done unsuccessfully with price number "+k+" on the list");
				log.info("Sorting is not done");
			}
			driver.navigate().refresh();
			log.info("Page is refreshed");
	    }
		log.info("");
	}

	@Then("^The results are filtered to display a smaller amount of items$")
	public void the_results_are_filtered_to_display_a_smaller_amount_of_items() throws Throwable {
		if(s==6)
		{
			porf="Pass";
		}
		log.info("Test "+porf+"ed");
		System.out.println("Sorting "+porf+"ed");
		wc.writeExcelData(porf,11,6);
		log.info("Test status written to excel sheet");
		quit();
		log.info("Browser quitted");
		log.info("");
	}
}
