package runner;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class testcase1 extends wrapperclass {
	static Logger log = Logger.getLogger(testcase.class.getName());
	ExcelReadWrite wc=new ExcelReadWrite();
	WebElement home,export,acccookies,result,searchopen,search,fproduct,quest,addtobag,mybag,max,min,prize;
	String product,prod,hometitle,searchtitle,prodstring,prodname,prodprice,porf="Fail",showing;
	int i,j=1,s=1,pf,k,pr;

	@When("^I do a multiple keyword search for \\(\\.\\.\\. \\.\\.\\.\\)$")
	public void i_do_a_multiple_keyword_search_for() throws Throwable {
		DOMConfigurator.configure("log4j.xml");
		//driver.navigate().to("https://www.lego.com/en-us");
		log.info("browser launched");
		System.out.println("Multiple keywords search commensing");
		log.info("Multiple keywords search commensing");
		try
		{
		export=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[5]/div/div[1]/div/button"));
		export.click();
		acccookies=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[3]/div/div[2]/button"));
		acccookies.click();
		log.info("Cookies accepted");
		}
		catch(Exception e)
		{}
		j=6;
		porf="Fail";
		for(i=6;i<=10;i++)
		{
	    searchopen=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/header/div/div[2]/div/div/button[1]"));
	    searchopen.click();
	    log.info("Search button clicked");
		product=wc.readExcelData(i);
		log.info("Product no:"+i+" is read from the excel sheet");
		search=driver.findElement(By.id("search-input"));
		search.sendKeys(product);
		log.info("Product entered into search box");
		TimeUnit.SECONDS.sleep(2);
		search.submit();
		log.info("Product submitted into search");
		result=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[1]/h3/span/span"));
		log.info("Search result shown");
		prod=result.getText();
		prodstring=prod.replace('"','#').replaceAll("#", "");
		System.out.println(prodstring);
		if(prodstring.contentEquals(product))
		{
			log.info("Multiple keyword search is done");
			System.out.println("Multiple keyword search is done for "+product);
			wc.writeExcelData("Multiple keyword search is done", i,5);
			log.info("Result written to excel sheet");
			j++;
		}
		else
		{
			log.info("Multiple keyword search is not done");
			System.out.println("Multiple keyword search is not done for "+product);
		}
		Thread.sleep(1000);
		fproduct=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div/div[2]/div/ul/li[1]/div/div[2]/div[1]/a/h2/span"));
		fproduct.click();
		log.info("First product is clicked");
		Thread.sleep(2000);
		try
		{
			quest=driver.findElement(By.xpath("//*[@id=\"noButton\"]"));
			quest.click();
			log.info("Questionnaire pop-up rejected");
		}
		catch(Exception e)
		{}
		Thread.sleep(1000);
		prodname=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/h1/span")).getText();
		log.info("Product name is extracted");
		prodprice=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/div[5]/div/span")).getText();
		log.info("Product name is extracted");
		System.out.println(prodname);
		System.out.println(prodprice);
		max=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[1]/div/div/div/div[1]/div/button/div[1]"));
		max.click();
		log.info("Image maximised");
		Thread.sleep(2000);
		screenshot("C://Users//Admin//Pictures//Screenshots//"+prodstring+".PNG");
		log.info("Screenshot is taken");
		min=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[1]/div/div[3]/div/div/div/div[1]/div/button/div"));
		min.click();
		log.info("Image minimised");
		Thread.sleep(2000);
		try
		{
			addtobag=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/div[6]/div[1]/div[2]/button"));
			addtobag.click();
		}
		catch(Exception e) 
		{
			List <WebElement>add=driver.findElements(By.xpath("//*[@id=\"main-content\"]/div/div[2]/div/div/div[2]/div[*]/div[1]/div[2]/button"));
			for(WebElement add1:add)
			{
				add1.click();
				break;
			}
		}
		log.info("Product added to bag");
		try
		{
		home=driver.findElement(By.xpath("//*[@id=\"main-content\"]/div/div[1]/div/ol/li[1]/a/span/span"));
		Thread.sleep(2000);
		home.click();
		}
		catch(Exception e)
		{
			driver.navigate().back();
			driver.navigate().back();
		}
		log.info("Navigated to home");
		Thread.sleep(3000);
		}
		System.out.println();
		log.info("");
	}

	@Then("^I see multiple keyword search result page with more than zero results$")
	public void i_see_multiple_keyword_search_result_page_with_more_than_zero_results() throws Throwable {
		if(j==11)
		{
			porf="Pass";
		}
		log.info("Test "+porf+"ed");
		System.out.println("Multiple keyword search "+porf+"ed");
		wc.writeExcelData(porf,1,6);
		log.info("Test status written to excel sheet");
		//mybag=driver.findElement(By.xpath("//*[@id="root"]/div/div[2]/header/div/div[1]/nav/ul[2]/li[3]/a");
		//mybag.click();
		log.info("");
	}
}
